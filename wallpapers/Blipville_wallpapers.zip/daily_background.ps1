# Blipville daily background changer (no Python needed)
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
Add-Type -TypeDefinition @"
using System.Runtime.InteropServices;
public class Wall { [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int SystemParametersInfo(int a, int b, string c, int d); }
"@
$key = "HKCU:\Control Panel\Desktop"
Set-ItemProperty $key WallpaperStyle "10"; Set-ItemProperty $key TileWallpaper "0"
$last = ""
while ($true) {
    $imgs = @(Get-ChildItem "$dir\bg_*.png" | Sort-Object Name)
    if ($imgs.Count -eq 0) { break }
    $pick = $imgs[[int]([datetime]::Today.Ticks / 864000000000 % $imgs.Count)].FullName
    if ($pick -ne $last) { [Wall]::SystemParametersInfo(20, 0, $pick, 3) | Out-Null; $last = $pick }
    if ($args -contains "--once") { break }
    Start-Sleep -Seconds 600
}
