@echo off
set "DEST=%APPDATA%\BlipvilleBackgrounds"
mkdir "%DEST%" 2>nul
copy /Y "%~dp0bg_*.png" "%DEST%" >nul
copy /Y "%~dp0daily_background.ps1" "%DEST%" >nul
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\Blipville Daily Background.lnk'); $s.TargetPath='powershell.exe'; $s.Arguments='-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \"%DEST%\daily_background.ps1\"'; $s.WindowStyle=7; $s.Save()"
start "" powershell -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%DEST%\daily_background.ps1"
echo Done! Today's Blipville background is set and it will change every day.
pause
