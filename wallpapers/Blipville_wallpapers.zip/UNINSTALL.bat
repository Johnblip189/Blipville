@echo off
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Blipville Daily Background.lnk" 2>nul
wmic process where "commandline like '%%daily_background.ps1%%' and name='powershell.exe'" delete >nul 2>nul
rmdir /s /q "%APPDATA%\BlipvilleBackgrounds" 2>nul
echo Removed. Your current wallpaper stays until you change it.
pause
